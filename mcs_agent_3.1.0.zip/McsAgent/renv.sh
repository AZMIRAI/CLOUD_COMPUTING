#!/bin/sh
export PATH=$OLD_PATH
